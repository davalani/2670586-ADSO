public class Principal{
	public static void main(String[] args) {
	
		
		Buscaminas ventana = new Buscaminas();

	}
}